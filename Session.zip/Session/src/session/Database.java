/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author telew
 */
public class Database {
    public Database(){
    }
    
    
    public void AddNewUser(Surfer surfer) throws IOException{
        try (CSVWriter writer = new CSVWriter(new FileWriter("database.txt", true))) {
            String[] entries = (surfer.ID + "#" + surfer.fname + "#" + surfer.lname + "#" + surfer.TempUnit + "#"  + surfer.WaveUnit + "#" + surfer.breakIdent + "#" + surfer.passw).split("#");
            String[] blank = (" # # # # # # #").split("#");//^^ takes in all parameters of Surfer object and appends them into a String array, values are separated/split by "#"
            writer.writeNext(entries);//writes the entry for the surfer 
            writer.writeNext(blank);//writes a blank line
        }
        catch(IOException e) {
            System.out.println("oh no");
        }
    }
    
    public String nextID(){
        String ID = "";
        Path path = Paths.get("database.txt");
        try {
          long lines = Files.lines(path).count();
          System.out.println(lines);
          long reallines = (lines/2) + 1;
          ID = "00" + reallines;
      } catch (IOException e) {
          e.printStackTrace();
      }
        return ID;
    }
    public void deleteUser(String ID){
        //find ID
        //delete
        
    }
        }
