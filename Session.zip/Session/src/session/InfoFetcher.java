/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session;
import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 * @author leof5
 */
public class InfoFetcher {
    public InfoFetcher(){
    
        
    }
    String getName(String ID){
        Document doc;
        String name = "";
        try {
            doc = Jsoup.connect("https://magicseaweed.com/Southlands-Surf-Report/" + ID + "/").get();
//            System.out.println("https://magicseaweed.com/Southlands-Surf-Report/" + ID + "/");
            name = doc.select("#msw-js-fct > header > h3 > span").text();
//            System.out.println(name);
            } catch (IOException ex) {
            ex.printStackTrace();
            }
        return name;
    }
    String getSurf(String ID, int unit){
        Document doc; //initialize document 
        Elements forecast = null; //forecast Element instantiated
        try {
            doc = Jsoup.connect("https://magicseaweed.com/Southlands-Surf-Report/" + ID + "/").get(); //writes the entire HTML of the link given into the doc
            forecast = doc.select("li[class=rating-text text-dark]");//the forecast is a specific selection of the doc, in this case an <li> tag with a class of "rating-text-dark"
            } catch (IOException ex) {
              JOptionPane.showMessageDialog(null, 
                  "Sorry dude i cant help you, that break doesnt exist! Unless its some secret spot", 
                              "Major Bummer man", 
                              JOptionPane.WARNING_MESSAGE);
        }
        if(unit == 1){//depending on the unit chosen by the user forecast is parsed to correct unit or remains the same (default meters)
            String splice = forecastSplicer.spliceSurf(forecast.text());//removes unnecessary "-" and "." for easy conversion e.g 0.6-0.9m becomes 0609,
            String surfinFeet = UnitDataParser.metersFeet(splice);//takes in the formatted forecast and returns full forecast but converted 0609 - "2-3ft"
            return surfinFeet;
            
        }
        if(unit == 0){
             return forecast.text();//returns default meters 
        }
        return forecast.text();
        }
    String getTemp(String ID, int unit) throws IOException{
        Document doc;
        Elements temp = null;
        String temperature = "";
        
        try {
            doc = Jsoup.connect("https://magicseaweed.com/Southlands-Surf-Report/" + ID + "/").get();
            
            if("btn btn-inverse btn-block msw-js-netcam-playable".equals(doc.select("body > div.cover > div.cover-inner > div.pages.clear-left.clear-right > div > div.msw-fc.msw-js-forecast.panoramic-page.msw-js-pano-page > div.msw-js-pano-netcam.panoramic-player.has-pro-banner > div.container-fluid.container-fluid-margin-lg.msw-js-netcam-playable-stack.hide-when-playing > div > div.col-sm-4.col-sm-offset-4.hidden-xs.margin-bottom > button").attr("class"))){
//                System.out.println("complex page");
                temp = doc.select("body > div.cover > div.cover-inner > div.pages.clear-left.clear-right > div > div.msw-fc.msw-js-forecast.panoramic-page.msw-js-pano-page > div:nth-child(5) > div > div.row > div > div.msw-col-fluid > div > div.row.margin-bottom > div.col-lg-7.col-md-7.col-sm-12.col-xs-12.msw-fc-current > div > div.col-lg-7.col-md-7.col-sm-7.col-xs-12 > ul.list-group.list-group-arrows.list-group-arrows-inverse.nomargin-bottom > li:nth-child(3) > p > strong:nth-child(5)");
                temperature = temp.text();
            }
            else if("btn btn-pro-inverse msw-js-pro-checkout pro-button23".equals(doc.select("body > div.cover > div.cover-inner > div.pages.clear-left.clear-right > div > div.msw-fc.msw-js-forecast > div:nth-child(2) > div:nth-child(2) > div > div > div.msw-col-fluid > div > div.panel.panel-module.panel-toolbar-sibling > div.row.row-full-width-xs.row-full-width-sm > div > section > div > div > a").attr("class"))){
//                System.out.println("live page");
                temp = doc.select("body > div.cover > div.cover-inner > div.pages.clear-left.clear-right > div > div.msw-fc.msw-js-forecast > div:nth-child(2) > div:nth-child(2) > div > div > div.msw-col-fluid > div > div.row.margin-bottom > div.col-lg-7.col-md-7.col-sm-12.col-xs-12.msw-fc-current > div > div.col-lg-7.col-md-7.col-sm-7.col-xs-12 > ul.list-group.list-group-arrows.list-group-arrows-inverse.nomargin-bottom > li:nth-child(3) > p > strong:nth-child(5)");
                temperature = temp.text();
            }
            
            
            else{
            temp = doc.select("body > div.cover > div.cover-inner > div.pages.clear-left.clear-right > div > div.msw-fc.msw-js-forecast > div:nth-child(2) > div:nth-child(2) > div > div > div.msw-col-fluid > div > div.row.margin-bottom > div.col-lg-7.col-md-7.col-sm-12.col-xs-12.msw-fc-current > div > div.col-lg-7.col-md-7.col-sm-7.col-xs-12 > ul.list-group.list-group-arrows.list-group-arrows-inverse.nomargin-bottom > li:nth-child(4) > p > strong:nth-child(5)");
//            System.out.println(temp.text()+"temptext");
            temperature = temp.text();
            }
            
            } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, 
                              "Something went wrong dude", 
                              "Major Bummer man", 
                              JOptionPane.WARNING_MESSAGE);
            
            }
        if(unit == 1){
            
            doc = Jsoup.connect("https://magicseaweed.com/Southlands-Surf-Report/" + ID + "/").get();
//            System.out.println("https://magicseaweed.com/Southlands-Surf-Report/" + ID + "/");
            UnitDataParser parse = new UnitDataParser();
//            System.out.println(temperature + "t");
            if(temperature == ""){
                System.out.println("no data found, sorry!");
                return "unable to fetch";
            }
            int newTemp = parse.celciusTofarenheight(Integer.parseInt(temperature));
            String newT = newTemp + "F";
            return newT;
            
        }
        return temperature + "C";
    }
    String getWind(String ID){
        Document doc;
        Elements wind = null;
        try {
            doc = Jsoup.connect("https://magicseaweed.com/Southlands-Surf-Report/" + ID + "/").get();

            wind = doc.select("p[class=h5 nomargin-top]");
            } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, 
                "Something went wrong dude", 
                "Major Bummer man", 
                JOptionPane.WARNING_MESSAGE);
            }
        return wind.text();
        }
    String asReport(String ID, int unitT, int unitW) throws IOException{
        String name = getName(ID);
        String surf = getSurf(ID, unitW);
        String wind = getWind(ID);
        String temp = getTemp(ID, unitT);
        return name + "\r\n" + "Surf Height:" + surf + "\r\n" + "Wind:" + wind + "\r\n" + "Temperature:" + temp + "\r\n" + "‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵";
    }
    String getImageAddress(){
        String addr = "https://ec2-im-1.msw.ms/md/image.php?id=" + ThreadLocalRandom.current().nextInt(100000, 399998 + 1) + "&type=PHOTOLAB&resize_type=STREAM_MEDIUM_SQUARE&fromS3";
        return addr;
    }
        
    }
    
