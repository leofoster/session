/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 * @author leof5
 */
public class Log {
    
    public Log(){
    }
    
    public void newLog(String name, Surfer user){
    try {
      File newL = new File(user.getID()+"." + name + ".txt"); //creates new file with name of USERID.dd.mm.yyyy.txt
      if (newL.createNewFile() == true) {
        System.out.println("File created: " + newL.getName());
      } else {
        System.out.println("File already exists.");
      }
    } catch (IOException e) {
      System.out.println("An error occurred.");
    }
    
    }
    public void writeLog(String filename, String input, Surfer user){
    try {
        try (FileWriter myWriter = new FileWriter(user.getID()+"." + filename)) {
            myWriter.write(input);//writes text to file
        }
      System.out.println("success");
      System.out.println(filename);
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
        
    }
    public static String retrieveLog(String filename, Surfer user){
        //todo
        char [] logg = new char[500]; //cannot pass a blank char array into the file reader 
        FileReader reader=null;//chose the maximum amount of text supported in the Large Text area
        try {
            reader = new FileReader(user.getID() +"." + filename + ".txt");//appends userID onto filename 
        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Sorry man, I went searching but couldnt find anything with the date " + filename );
        }
        try {
            reader.read(logg);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Went searching couldnt find anything man, sorry about that, nothing for the date :" + filename );
        }
        return String.valueOf(logg); //returns string value of log contents
    }
}
