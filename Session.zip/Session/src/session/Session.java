/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package session;
import java.awt.Component;
import java.io.IOException;
import java.util.Scanner;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
/**
 *
 * @author leof5
 */
public class Session {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
//        Scanner scan = new Scanner(System.in);
//        InfoFetcher fetch = new InfoFetcher();
        
//        while(true){
//            String a = scan.nextLine();
//            System.out.println(fetch.getSurf(a, 0));
//            System.out.println(fetch.getTemp(a, 0));
//            System.out.println(fetch.getWind(a));
//        }
//        UnitDataParser parse = new UnitDataParser();
//        String raw = fetch.getSurf("3893", 0);
//        System.out.println(fetch.getTemp("3930", 0));
//        System.out.println(fetch.getTemp("3930", 1));
//        System.out.println(raw);
//        System.out.println(fetch.getImageAddress());
      //(ID, fname, lname, TempPref, WavePRef, breakID, passw)
//        Surfer man = new Surfer("0001","Leo","Foster",0,0,"3930","ocean");
//        Home home = new Home(man);
//        home.setVisible(true);
//
        Login login = new Login();
        login.setVisible(true);
        
        
//        String newvalue = parse.metersFeet(spliced);
//        System.out.println(newvalue);
        
//        forecastSplicer splice = new forecastSplicer();
//        System.out.println(splice.spliceSurf(fetcher.getSurf("3930")));
//        System.out.println("splice testing");
//        splice.spliceSurf("Flat");
//        splice.spliceSurf("2-4.5m");
//        
//        System.out.println("oother");
//        fetcher.getSurf("3450");
//        fetcher.getSurf("1112");
//        fetcher.getSurf("1673");
//        fetcher.getWind("0223");
//        fetcher.getTides("3930");
//        fetcher.getTemp("2930");
        
    }
    
}
