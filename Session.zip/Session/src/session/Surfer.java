/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

/**
 *
 * @author telew
 */
public class Surfer {
    String ID;
    String fname;
    String lname;
    int WaveUnit;
    int TempUnit;
    String passw;
    String breakIdent;
    public Surfer(){
        String ID = "0000";
        String fName = "Generic";
        String lname = "Surfer";
        int WaveUnit = 1;
        int TempUnit = 1;
        String breakkid = "3930";
        String passw = "ocean";
    }
    public Surfer(String SurfID, String firstName, String lastName, int WaveU,int TempU, String breakID, String password){
        ID = SurfID;
        fname = firstName;
        lname = lastName;
        WaveUnit = WaveU;
        TempUnit = TempU;
        passw = password;
        breakIdent = breakID;
        
    }
    String getFullName(){
        String fullname = fname + " " + lname;
        return fullname;
    }
    String getID(){
        return ID;
    }
    int getWaveUnit(){
        return WaveUnit;
    }
    int getTempUnit(){
        return TempUnit;
    }
    String getbreakID(){
        return breakIdent;
    }
    String getPass(){
        return passw;
    }
}
