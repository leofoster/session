/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session;
/**
 *
 * @author leof5
 */
//0.1-0.2m
//01234567
public class UnitDataParser {
    static float meterToFeet = 3.28f;
    static float kphTomph = 0.62f;
    public UnitDataParser(){
    }
    public static String metersFeet(String spliced){
        float surf1 = Float.valueOf(spliced.substring(0, 3));
        float surf2 = Float.valueOf(spliced.substring(3, 6));
        String newforecast = Math.round(surf1 * 3.28) + "-" + Math.round(surf2 * 3.28) + "ft";
        return newforecast;
    }
    public int celciusTofarenheight(int value){
        int newvalue = (value*9/5)+32;
        return newvalue;
    }
    public int kphMph(float value){
        value = value * 0.62f;
        int newvalue = Math.round(value);
        return newvalue;
    }
}
