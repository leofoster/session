/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session;
/**
 *
 * @author leof5
 */
public class forecastSplicer {
    //1.3-2m
    //012345
    //2-1.3m
    //012345
    //0.5-0.9m
    //01234567
    //Flat
    //0123
    public static String spliceSurf(String surf){
        String surf1 = "";
        String surf2 = "";
        System.out.println(surf.length());
        if(surf.length() == 8){
            surf1 = surf.substring(0,3);
            surf2 = surf.substring(4,7);
        }
        System.out.println("her");
        if(surf.length() == 4){
            surf1 = "0";
            surf2 = "0";
        }
        if(surf.length() == 6) {
            if(surf.charAt(1) == '.'){
                surf1 = surf.substring(0,3);
                surf2 = Character.toString(surf.charAt(4))+ ".0";
            }
            if(surf.charAt(3) == '.'){
                surf2 = surf.substring(2,5);
                surf1 = Character.toString(surf.charAt(0))+ ".0";
            }
            
            
        }
        System.out.println(surf1+surf2);
        return surf1+surf2;
    }
}
